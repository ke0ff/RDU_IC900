//******************************************************************************************
//		main.c
//
//		Copyright (c), June 2022, all rights reserved.
//		Joseph Haas
//		KE0FF
//		www.ke0ff.org
//
//		Multi-Function Microphone interface application for the ATTINY1604
//
//		This application is part of the IC-900 RDU Clone, multi-function microphone interface.
//		The MFMIC uses the UP/DN signal on the IC-900 microphone connector (intercepted inside
//		the IC-900 "A-Unit") to transfer keypress data from the mic to the RDU.  The connection
//		to the RDU is via a new cable that conveys TTL(3.3V) serial I/O from the RDU "debug UART"
//		to/from the IC-900 A-Unit.
//
//		A DSUB-9 (female) serial COM port connector is provided at the A-Unit for connection to
//		a host PC for remote control and system memory maintenance tasks (38.4 Kb, N81).  The
//		presence of CTS at this connector causes the microphone data line to be interrupted,
//		replaced with the COM port data line.  Bridging pins 7 & 8 of the host connector accomplishes
//		this for terminal systems which do not have a CTS sourced.
//
//		When the host PC is connected, the MF-MIC data is disabled.  When the host PC is removed,
//		serial data from the HM-133 DTMF interface is presented to the RDU and is monitored by
//		the ATtiny application to allow the ATtiny to "replace" the UP/DN button functionality.
//
//		SW requirements:
//		The UP/DN signal is digitized by the ATtiny ADC (PA3) which uses the resulting data stream to
//		distinguish between HM-133 serial data and an HM-14 UP/DN button press.  The ADC is sampled
//		at 5ms intervals.  If a series of 32% readings are detected, the system interprets a
//		DOWN button press and activates the DN GPIO.  0% readings are interpreted as "UP".
//
//		An algorithm must be deployed to juggle between the serial commands and the HM-14 buttons.
//		The IPL default is serial commands.  A serial break or 3 consecutive 32% readings invokes
//		HM-14 mode.  In HM-14 mode, the ADC controls the UP and DN GPIOs.  If a valid serial command
//		is decoded from the HM-133, the serial mode is re-established.  This method allows for the
//		microphones to be hot swapped without any operator actions to signify the swap.
//
//		The system monitors the CTS_HOST input and echoes this state to the MIC_DATA_EN output.
//
//		The "I'm alive" LED (PB1) is pulsed once per sec (10% on duty cycle).
//
//		The UART sends an IPL message and responds to the "???" help command with a low-resolution
//		command list.
//
//		HM-133 commands are 5-bytes long: <'~'><cmd><p/h/r/R><chk><\r>
//				<'~'> is fixed preamble
//				<cmd> is a single-byte alpha-numeric command
//				<p/h/r/R> is a single character for key (p)ress, (h)old, (r)elease, or aborted (R)elease
//				<chk> = (<cmd> EOR <p/h/r/R>) OR 0x80
//				<\r> is <CR>, ASCII 0x0d
//
//				Two consecutive "?" characters plus <CR> returns the help list.
//
//**************************************************************************************-jhaas

#define REV_STR		"V0.1%\n"	// current revision -- !! change only the n.n numeric revision characters !!

//
// Rev 0.1, 06-26-22		initial release				-joe haas
// Rev 0.0, 06-22-22		initial creation revision	-joe haas
// Origin Date: 06-22-22

#include <atmel_start.h>
#include <stdio.h>
#include <avr/interrupt.h>
#include <driver_init.h>
//#include "nvmctrl_basic.h"

// local declarations
uint8_t chkmsg(char* sptr);

//char* scans(char* s);


#undef DEBUG

//*************************
// debug trap -- uncomment the following line to enable debug code
//#define DEBUG
//*************************

// PortA defines
#define	CTS_HOST	0x02		// CTS "to" host ("1" to enable)
#define DN_GPIO		0x10		// up/dn I/O defines
#define UP_GPIO		0x20
#define HOST_RTS	0x40		// Host active input
#define MIC_DATA_EN	0x80		// control output to serial switch IC.  "1" == mic-to-RDU connection enabled, else term-to-RDU is enabled)

// I'm alive LED bit
#define LED		0x02		// PB1

#define BUF_MAX		20
char ubuf[BUF_MAX];			// command line serial buffer

//*********************************************
// main() holds the primary application core:
//	* initializes the MCU
//	* sends startup message to UART (38400 baud)
//	* code to process the UART messages is TBD
//		cmds: { ** see driver_init.h ** }
//			"-"  NAME - description
//
int main(void)
{
	uint8_t		alive = 0;					// alive LED phase counter
	uint8_t		udmem = 0;					// up/dn change memory flag
	uint8_t		anud_enable = 1;			// analog up/dn enable flag
	uint8_t		porta_mem = ~PORTA_IN;		// port A change mem (force init at IPL)

	uint8_t		i;							// temps
//	char*		cptr;

	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	sei();													//enabling global interrupt

	// IPL start banner
	wait_T(START_WAIT);
	putsu("\n#MFmic IPL: ");
	putsu(REV_STR);
	// main process loop...
	while (1) {
		// process RTS input if there has been a change 
		i = PORTA_IN;
		if((i & HOST_RTS) ^ porta_mem){
			porta_mem = i & HOST_RTS;
			if(porta_mem){
				PORTA_OUT |= MIC_DATA_EN;
			}else{
				PORTA_OUT &= ~MIC_DATA_EN;
			}
		}
		// process I'm Alive LED... "blinks" once every 5 sec
		if(!chk_tmr1(0)){
			alive++;
			if((alive) & 0x01){
				chk_tmr1(LED0_PULSE);
				PORTB.OUT &= ~0x02;
			}else{
				chk_tmr1(LED1_PULSE);
				PORTB.OUT |= 0x02;
			}
		}
		// process analog up/dn button
		if(is_adc_rdy()){
			i =  qual_adc();
			if(anud_enable){
				if(i != udmem){ 
					udmem = i;
					PORTA_OUT &= ~(UP_GPIO|DN_GPIO);		// failsafe these outputs to GND
					switch(i){
						case IS_UP:
							DN_set_dir(
								// <y> Pin direction
								// <id> pad_dir
								// <PORT_DIR_OFF"> Off
								// <PORT_DIR_IN"> In
								// <PORT_DIR_OUT"> Out
								PORT_DIR_IN);
							UP_set_dir(
								// <y> Pin direction
								// <id> pad_dir
								// <PORT_DIR_OFF"> Off
								// <PORT_DIR_IN"> In
								// <PORT_DIR_OUT"> Out
								PORT_DIR_OUT);
							putsu("#UP%\n");
							break;
			
						case IS_DN:
							DN_set_dir(
								// <y> Pin direction
								// <id> pad_dir
								// <PORT_DIR_OFF"> Off
								// <PORT_DIR_IN"> In
								// <PORT_DIR_OUT"> Out
								PORT_DIR_OUT);
							UP_set_dir(
								// <y> Pin direction
								// <id> pad_dir
								// <PORT_DIR_OFF"> Off
								// <PORT_DIR_IN"> In
								// <PORT_DIR_OUT"> Out
								PORT_DIR_IN);
							putsu("#dn%\n");
							break;
				
						default:
							DN_set_dir(
								// <y> Pin direction
								// <id> pad_dir
								// <PORT_DIR_OFF"> Off
								// <PORT_DIR_IN"> In
								// <PORT_DIR_OUT"> Out
								PORT_DIR_IN);
							UP_set_dir(
								// <y> Pin direction
								// <id> pad_dir
								// <PORT_DIR_OFF"> Off
								// <PORT_DIR_IN"> In
								// <PORT_DIR_OUT"> Out
								PORT_DIR_IN);
							putsu("#OPEN%\n");
							break;			
					}
				}else{
					if(i == IS_DN){
						// adc detection disabled AND adc down detected => re-enable adc mode
						anud_enable = 1;
						putsu("#SDN%\n");
					}
				}
			}
		}
		// process break-received (enables analog u/d)
		i = getstat(1);
		if(i & BRK_DET){
			anud_enable = 1;
			putsu("#SBRK%\n");
		}
		// process serial input messages
		if(gotmsg(1)){
			gets(ubuf);
/*			if(ubuf[0] == '>'){
				// open text cmd format: <cmd><parm>... code creates msg with <chk> and recycles
				ubuf[0] = ubuf[1];
				ubuf[1] = ubuf[2];
				ubuf[2] = (ubuf[0] ^ ubuf[1]) | 0x80;
				ubuf[3] = '\r';
			}*/
			i = chkmsg(ubuf);
			if(i){
				// trap valid message (i = CMDid)
				// first, clear analog u/d enable
				anud_enable = 0;
				if(ubuf[0] == 'u') putsu("#UP%\n");
			}else{
				// invalid msg trap
				if((ubuf[0] == '?') && (ubuf[1] == '?')){
					// help list
					putsu("\nMFmic: ");
					putsu(REV_STR);
					putsu("(c) KE0FF 06-26-2022\n");
					putsu("*** msg=5 ASCII bytes: <'~'><cmd><parm><chk><\\r>\n");
					putsu("*** <chk>=(<cmd> EOR <parm>) OR 0x80\n");
				}else{
					// err response
					putsu("#CMDERR%\n");
				}
			}
		}
	} // end while(1)
} // end main()

//*********************************************
// chkmsg() examines the message at sptr and returns the following:
//	0: if the check test fails {<chk> = (<cmd> EOR <d/u/h>) OR 0x80}
//	u: if up
//	d: if dn
//	U: if up hold
//	D: if dn hold
//	r: if release
//	0xff otherwise valid cmd msg

uint8_t chkmsg(char* sptr){
	char	c;
	char	p;
	uint8_t	rtn = 0;	// default to invalid msg

	// calculate check byte
	c = (*(sptr+1) ^ *(sptr+2)) | 0x80;
	// verify check byte and <CR> are correct in msg
	if((*sptr == '~') && (c == *(sptr+3)) && (*(sptr+4) == '\r')){
		// get parm byte
		p = *(sptr+2);
		// msg is valid, test to see if it is an up/dn cmd
		//	create composite return value
		switch(*(sptr+1)){
			case HM_UP:
				switch(p){
					case 'p':
						rtn = 'u';
						break;

					case 'h':
						rtn = 'U';
						break;
					
					case 'r':
					default:
						rtn = 'r';
				}
				break;

			case HM_DN:
				switch(p){
					case 'p':
					rtn = 'd';
					break;

					case 'h':
					rtn = 'D';
					break;
					
					case 'r':
					default:
					rtn = 'r';
				}
				break;

			default:
				rtn = 0xff;
				break;
		}
	}
	return rtn;
}


//*********************************************
// RxD edge intr.  Captures RX data and places into circular buffer
/*
ISR(PORTB_PORT_vect){

	PORTB.PIN3CTRL = 0;		// disable RxD edge ISR
//	DISABLE_INTERRUPTS();
}*/

// eof
