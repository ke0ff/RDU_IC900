//******************************************************************************************
//		main.c
//
//		Copyright (c), June 2022, all rights reserved.
//		Joseph Haas
//		KE0FF
//		www.ke0ff.org
//
//		Multi-Function Microphone interface application for the ATTINY1604
//
//		This application is part of the IC-900 RDU Clone, multi-function microphone interface.
//		The MFMIC uses the UP/DN signal on the IC-900 microphone connector (intercepted inside
//		the IC-900 "A-Unit") to transfer keypress data from the HM-133 DTMF adapter interface to
//		the RDU.  The COM connection to the RDU is via a new cable that conveys TTL(3.3V) serial
//		I/O from the RDU "debug UART" to/from the IC-900 A-Unit.
//
//		A DSUB-9 (female) serial COM port connector is provided at the A-Unit for connection to
//		a host PC COM port for remote control and system memory maintenance tasks (115.2 Kb, N81).
//		The presence of CTS at this connector causes the microphone data line to be interrupted and
//		switched to the COM port data line.  Bridging pins 7 & 8 of the host connector also accomplishes
//		this for terminal systems which do not provide a CTS signal.
//
//		When the host PC is connected, the MF-MIC data path to the RDU is disabled but the ATTINY continues
//		to receive MIC data.  When the host PC is removed, serial data from the HM-133 DTMF interface is
//		presented to the RDU.  TX data from the RDU is always passed to the COM connector.  A MAX-232 level
//		translator is used to interface the RDU TTL signals to the RS-232 COM connector.  The MFmic data
//		monitored by the ATtiny application allows the ATtiny to "replace" the UP/DN button functionality
//		as follows:
//
//			1) An analog up-dn mic is used (such as the HM-14) -- The ATTINY digitizes the analog voltage
//				and produces a calculation that determines if "UP" or "DN" are pressed.  These states
//				are echoed to GPIO pins that connect to the A-unit up/dn input.  In this state, the data
//				switch is forced to the remote PC input (regardless of the RTS status) to prevent button
//				presses from being passed to the RDU as false UART traffic.
//
//			2) An HM-133 interface is connected AND there is a PC connection established -- In this case,
//				the ATTINY monitors the serial data from the HM-133 interface and passes commands to
//				the UP/DN GPIO pins.
//
//			3) An HM-133 is connected and there is no PC connected to the system -- In this case, the
//				serial data is monitored, but ignored, and that data passes to the RDU.
//
//		Automatic mic detection is employed using the following "clues":
//			1) [analog]: a 0x00 byte (NULL) is received at the UART input.  This is indicative of the UP button
//				(GND) being pressed and signals that an analog mic is connected.
//			2) [analog]: a "DN" voltage is detected.  Assuming a low-pass integrator is present on the ADC input,
//				it is not possible for any currently defined MIC data message from the HM133 interface
//				to allow an "UP or "DN" voltage to be produced over the 3-sample period used to monitor
//				the analog input.
//			3) [digital]: any valid HM-133 message is detected.  This signals that an HM-133 interface is present.
//				The message validation happens before the parsing, so there is no data loss if the first
//				message is an UP or DN button.
//
//		SW requirements:
//		The UP/DN signal is digitized by the ATtiny ADC (PA3) which uses the resulting data stream to
//		distinguish between HM-133 serial data and an HM-14 UP/DN button press.  The ADC is sampled
//		at 5ms intervals into a 3-element, wrap-around array.  A min/max algorithm is used to test if all
//		samples lie within one of the three defined voltage states (UP, DN, or OPEN).  If a series of 32%
//		readings are detected, the system interprets a DOWN button press and activates the DN GPIO.  0%
//		readings are interpreted as "UP".
//
//		An algorithm shall be deployed to juggle between the serial commands and the HM-14 buttons.
//		The IPL default is analog buttons.  A serial break or 3 consecutive "DN" readings invokes
//		HM-14 mode.  In HM-14 mode, the ADC controls the UP and DN GPIOs.  If a valid serial command
//		is decoded from the HM-133, the serial mode is established.  This method allows for the microphones
//		to be hot swapped without any additional operator intervention.
//
//		The system monitors the RTS_HOST input and echoes this state to the MIC_DATA_EN output qualified
//		against the current mic mode status.
//
//		A "loss of remote" timer shall to be maintained to prevent the UP/DN outputs from being "locked up"
//		should there be a loss of data from the HM-133 interface.  Valid "HOLD" messages reset the timer.
//		if the timer reaches zero, the GPIO signals are released.
//
//		The "I'm alive" LED (PB1) is pulsed on for 100ms once every 5 sec.
//
//		The UART shall send an IPL message and responds to the "??" help command with a low-resolution
//		command list:
//
//		HM-133 commands are 5-bytes long: <'~'><cmd><p/h/r/R><chk><\r>
//				<'~'> is fixed preamble
//				<cmd> is a single-byte alpha-numeric command
//				<p/h/r/R> is a single character for key (p)ress, (h)old, dn (r)elease, or up (R)elease
//				<chk> = (<cmd> EOR <p/h/r/R>) OR 0x80
//				<\r> is <CR>, ASCII 0x0d
//
//				Two consecutive "?" characters plus <CR> returns the help list.
//
//**************************************************************************************-jhaas

#define REV_STR		"V0.3%\n"	// current revision -- !! change only the n.n numeric revision characters !!
								// 22:15 CDT 06/30/2022

/////////////////////// REVISION NOTES //////////////////////////
//
// Rev 0.3, 06/29/22, jmh		Feature complete, ready for field trials
// Rev 0.1, 06-26-22, jmh		initial release
// Rev 0.0, 06-22-22, jmh		initial creation revision
// Origin Date: 06-22-22
/////////////////////////////////////////////////////////////////

#include <atmel_start.h>
#include <stdio.h>
#include <avr/interrupt.h>
#include <driver_init.h>

// local declarations
uint8_t chkmsg(char* sptr);


#undef DEBUG

//*************************
// debug trap -- uncomment the following line to enable debug code
//#define DEBUG
//*************************

// PortA defines
#define	CTS_HOST	0x02		// PA1 CTS "to" host ("1" to enable)
#define DN_GPIO		0x10		// PA4 up/dn I/O defines
#define UP_GPIO		0x20		// PA5
#define HOST_RTS	0x40		// PA6 Host active input
#define MIC_DATA_EN	0x80		// PA7 control output to serial switch IC.  "1" == mic-to-RDU connection enabled, else term-to-RDU is enabled)
// PA0 = UPDI
// PA3 = ANIN3 (analog U/D)
// PA2 = not used

// PortB defines
#define LED		0x02			// PB1 I'm alive LED bit
// PB3 = RXD
// PB2 = TXD
// PB0 = not used

#define BUF_MAX		20
char ubuf[BUF_MAX];				// UART msg buffer

//*********************************************
// main() holds the primary application core:
//	* initializes the MCU
//	* sends startup message to periphs
//	* code to process the main application loop
//
int main(void)
{
				uint8_t		alive = 0;					// alive LED phase counter
	volatile	uint8_t		udmem = 0;					// up/dn change memory flag
	volatile	uint8_t		mode_ud = ANA_UD;			// up/dn mode flag (ANA_UD, IDL_UD, & DIG_UD)
	volatile	uint8_t		rts_mem = ~PORTA_IN;		// port A change mem (force init at IPL)
	volatile	uint8_t		mode_mem = 0xff;			// mode change mem (drives data switch)

	uint8_t		i;							// temps

	/* Initializes MCU, drivers and middleware */
	PORTA_DIR &= ~(UP_GPIO|DN_GPIO);						// IPL these signals to OPEN
	atmel_start_init();
	sei();													//enabling global interrupt

	// IPL start banner
	wait_T(START_WAIT);
	putsu("\n#MFmic IPL: ");
	putsu(REV_STR);
	// main process loop...
	while (1) {
		// process RTS input if there has been a change in RTS or mode_ud
		i = PORTA_IN;
		if(((i & HOST_RTS) ^ rts_mem) || (mode_mem != mode_ud)){
			// update state memories
			rts_mem = i & HOST_RTS;
			mode_mem = mode_ud;
			if(mode_ud == ANA_UD){
				// all other modes, data switch is disabled
				PORTA_OUT &= ~MIC_DATA_EN;
			}else{
				// dig mode, data switch setting is based on RTS state
				if(rts_mem){
					PORTA_OUT |= MIC_DATA_EN;
					mode_ud = IDL_UD;
				}else{
					PORTA_OUT &= ~MIC_DATA_EN;
					mode_ud = DIG_UD;
				}			
			}
		}
		// process I'm Alive LED... "blinks" once every 5 sec
		if(!chk_tmr1(0)){
			alive++;
			if((alive) & 0x01){
				chk_tmr1(LED0_PULSE);
				PORTB.OUT &= ~0x02;
			}else{
				chk_tmr1(LED1_PULSE);
				PORTB.OUT |= 0x02;
			}
		}
		// process analog up/dn button
		if(is_adc_rdy()){
			i =  qual_adc();
			// detect analog DN press mode-change
			if(mode_ud != ANA_UD){
				if(i == IS_DN){
					mode_ud = ANA_UD;
					DN_set_dir(
					// <y> Pin direction
					// <id> pad_dir
					// <PORT_DIR_OFF"> Off
					// <PORT_DIR_IN"> In
					// <PORT_DIR_OUT"> Out
					PORT_DIR_IN);
					UP_set_dir(
					// <y> Pin direction
					// <id> pad_dir
					// <PORT_DIR_OFF"> Off
					// <PORT_DIR_IN"> In
					// <PORT_DIR_OUT"> Out
					PORT_DIR_IN);
					putsu("#ANASW%\n");
				}
			}
			if(mode_ud == ANA_UD){
				if(i != udmem){ 
					udmem = i;
					PORTA_DIR &= ~(UP_GPIO|DN_GPIO);		// failsafe these outputs to OPEN
					PORTA_OUT &= ~(UP_GPIO|DN_GPIO);
					switch(i){
						case IS_UP:
							DN_set_dir(
								// <y> Pin direction
								// <id> pad_dir
								// <PORT_DIR_OFF"> Off
								// <PORT_DIR_IN"> In
								// <PORT_DIR_OUT"> Out
								PORT_DIR_IN);
							UP_set_dir(
								// <y> Pin direction
								// <id> pad_dir
								// <PORT_DIR_OFF"> Off
								// <PORT_DIR_IN"> In
								// <PORT_DIR_OUT"> Out
								PORT_DIR_OUT);
							putsu("#UP%\n");
							break;
			
						case IS_DN:
							DN_set_dir(
							// <y> Pin direction
							// <id> pad_dir
							// <PORT_DIR_OFF"> Off
							// <PORT_DIR_IN"> In
							// <PORT_DIR_OUT"> Out
							PORT_DIR_OUT);
							UP_set_dir(
							// <y> Pin direction
							// <id> pad_dir
							// <PORT_DIR_OFF"> Off
							// <PORT_DIR_IN"> In
							// <PORT_DIR_OUT"> Out
							PORT_DIR_IN);
							putsu("#DN%\n");
							break;
				
						default:
							DN_set_dir(
								// <y> Pin direction
								// <id> pad_dir
								// <PORT_DIR_OFF"> Off
								// <PORT_DIR_IN"> In
								// <PORT_DIR_OUT"> Out
								PORT_DIR_IN);
							UP_set_dir(
								// <y> Pin direction
								// <id> pad_dir
								// <PORT_DIR_OFF"> Off
								// <PORT_DIR_IN"> In
								// <PORT_DIR_OUT"> Out
								PORT_DIR_IN);
							putsu("#OPEN%\n");
							break;			
					}
				}
			}
		}
		// check for mode change -- process break-received (enables analog u/d)
		i = getstat(1);
		if(mode_ud != ANA_UD){
			if(i & BRK_DET){
				mode_ud = ANA_UD;
				DN_set_dir(
				// <y> Pin direction
				// <id> pad_dir
				// <PORT_DIR_OFF"> Off
				// <PORT_DIR_IN"> In
				// <PORT_DIR_OUT"> Out
				PORT_DIR_IN);
				UP_set_dir(
				// <y> Pin direction
				// <id> pad_dir
				// <PORT_DIR_OFF"> Off
				// <PORT_DIR_IN"> In
				// <PORT_DIR_OUT"> Out
				PORT_DIR_IN);
				putsu("#SBRK%\n");
			}
		}
		// process serial msg timeout trap
		if(mode_ud != ANA_UD){
			if((PORTA_DIR & (UP_GPIO|DN_GPIO)) && !chk_tmr2(0)){
				DN_set_dir(
				// <y> Pin direction
				// <id> pad_dir
				// <PORT_DIR_OFF"> Off
				// <PORT_DIR_IN"> In
				// <PORT_DIR_OUT"> Out
				PORT_DIR_IN);
				UP_set_dir(
				// <y> Pin direction
				// <id> pad_dir
				// <PORT_DIR_OFF"> Off
				// <PORT_DIR_IN"> In
				// <PORT_DIR_OUT"> Out
				PORT_DIR_IN);
				putsu("#timout%\n");
			}
		}
		// process serial input messages
		if(gotmsg(1)){
			gets(ubuf);
			i = chkmsg(ubuf);
			// trap valid message (i = CMDid)
			if(i){
				// process mode change
				if(PORTA_OUT & MIC_DATA_EN){
					mode_ud = IDL_UD;					// mic data pass thru -- don't interpret data-up/dn
				}else{
					mode_ud = DIG_UD;					// computer selected -- interpret data-up/dn
				}
				// if digital mode, parse received data
				if(mode_ud == DIG_UD){
					switch(i){
						default:						// any non-up/dn message resets the UP/DN port pins
							DN_set_dir(
							// <y> Pin direction
							// <id> pad_dir
							// <PORT_DIR_OFF"> Off
							// <PORT_DIR_IN"> In
							// <PORT_DIR_OUT"> Out
							PORT_DIR_IN);
							UP_set_dir(
							// <y> Pin direction
							// <id> pad_dir
							// <PORT_DIR_OFF"> Off
							// <PORT_DIR_IN"> In
							// <PORT_DIR_OUT"> Out
							PORT_DIR_IN);
							putsu("#na%\n");
							break;

						case UP_PRS:					// initial press - UP
							DN_set_dir(
							// <y> Pin direction
							// <id> pad_dir
							// <PORT_DIR_OFF"> Off
							// <PORT_DIR_IN"> In
							// <PORT_DIR_OUT"> Out
							PORT_DIR_IN);
							UP_set_dir(
							// <y> Pin direction
							// <id> pad_dir
							// <PORT_DIR_OFF"> Off
							// <PORT_DIR_IN"> In
							// <PORT_DIR_OUT"> Out
							PORT_DIR_OUT);
							putsu("#up%\n");
							chk_tmr2(KEY_TIMOUT);		// init timeout
							break;

						case DN_PRS:					// initial press - DN
							DN_set_dir(
							// <y> Pin direction
							// <id> pad_dir
							// <PORT_DIR_OFF"> Off
							// <PORT_DIR_IN"> In
							// <PORT_DIR_OUT"> Out
							PORT_DIR_OUT);
							UP_set_dir(
							// <y> Pin direction
							// <id> pad_dir
							// <PORT_DIR_OFF"> Off
							// <PORT_DIR_IN"> In
							// <PORT_DIR_OUT"> Out
							PORT_DIR_IN);
							putsu("#dn%\n");
							chk_tmr2(KEY_TIMOUT);		// init timeout
							break;

						case UP_REL:					// release either UP or DN
						case DN_REL:
							DN_set_dir(
							// <y> Pin direction
							// <id> pad_dir
							// <PORT_DIR_OFF"> Off
							// <PORT_DIR_IN"> In
							// <PORT_DIR_OUT"> Out
							PORT_DIR_IN);
							UP_set_dir(
							// <y> Pin direction
							// <id> pad_dir
							// <PORT_DIR_OFF"> Off
							// <PORT_DIR_IN"> In
							// <PORT_DIR_OUT"> Out
							PORT_DIR_IN);
							putsu("#open%\n");
							break;

						case DN_HLD:					// hold either UP or DN
						case UP_HLD:
							chk_tmr2(KEY_TIMOUT);		// reset timeout
							break;
					}
				}
			}else{
				// invalid msg trap
				if((ubuf[0] == '?') && (ubuf[1] == '?')){
					// help list
					putsu("\nMFmic: ");
					putsu(REV_STR);
					putsu("(c) KE0FF 06-26-2022\n");
					putsu("*** msg=5 ASCII bytes: <'~'><cmd><parm><chk><\\r>\n");
					putsu("*** <chk>=(<cmd> EOR <parm>) OR 0x80\n");
				}else{
					// err response
					putsu("#CMDERR%\n");
				}
			}
		}
	} // end while(1)
} // end main()

//*********************************************
// chkmsg() examines the message at sptr and returns the following:
//	0: if the check test fails {<chk> = (<cmd> EOR <d/u/h>) OR 0x80}
//		this indicates an invalid msg
//	U: if up
//	D: if dn
//	u: if up hold
//	d: if dn hold
//	R: if up release
//	r: if dn release
//	0xff if otherwise valid msg

uint8_t chkmsg(char* sptr){
	char	c;
	char	p;
	uint8_t	rtn = 0;	// default to invalid msg

	// calculate check byte
	c = (*(sptr+1) ^ *(sptr+2)) | 0x80;
	// verify check byte and <CR> are correct in msg
	if((*sptr == '~') && (c == *(sptr+3)) && (*(sptr+4) == '\r')){
		// get parm byte
		p = *(sptr+2);
		// msg is valid... test to see if it is an up/dn cmd
		//	if yes, create composite return value
		switch(*(sptr+1)){
			case HM_UP:
				switch(p){
					case 'p':
						rtn = UP_PRS;
						break;

					case 'h':
						rtn = UP_HLD;
						break;
					
					case 'r':
					default:
						rtn = UP_REL;
						break;
				}
				break;

			case HM_DN:
				switch(p){
					case 'p':
					rtn = DN_PRS;
					break;

					case 'h':
					rtn = DN_HLD;
					break;
					
					case 'r':
					default:
					rtn = DN_REL;
					break;
				}
				break;

			default:
				rtn = 0xff;
				break;
		}
	}
	return rtn;
}

// eof
