cmd_fn.c archive


				case adc_tst:													// CIV test cmd
					if(pw){
						// "W" displays peripheral properties reg
						ii = ADC0_PP_R;
						sprintf(obuf,"ADC0_PP: 0x%08x",ii);
						putsQ(obuf);
					}
					if(!pc){
						// normal exec is one line (no "C")
						ip = adc_buf;
						i = adc_in(ip);
						sprintf(obuf,"#samps: %u,  S0: %u,  S1: %u",i,adc_buf[1],adc_buf[7]);
						putsQ(obuf);
						if(px){
							// if "X", display status bits
							sprintf(obuf,"stats:     s0: %04x, s1: %04x",adc_buf[0],adc_buf[6]);
							putsQ(obuf);
						}
					}else{
#ifdef DEBUG
						// if "C", display milti-line (until ESC)
						do{														// display ascii version of msg
							ip = adc_buf;
							i = adc_in(ip);
							j = (2 * i) - 1;
							sprintf(obuf,"#samps: %u,  R0: %u,  R3: %u",i,adc_buf[1],adc_buf[j]);
							putsQ(obuf);
							if(pv){
								// if "V", display eng units
								//	TJ = 147.5 - (75 * (rawADC * 3.29 / 4096))
								fa = 147.5 - ((float)adc_buf[j] * 60.242E-3);
								fb = (float)adc_buf[1] * 803.223E-6;
								sprintf(obuf,"eng:  V0: %.2f V, Tj: %.2f C",fb,fa);
								putsQ(obuf);
								ii = ((1475 * 4096) - (75 * 33 * (U32)adc_buf[j])) / 40960;
								sprintf(obuf,"eng:  V0: %.2f V, Tj: %3d C",fb,ii);
								putsQ(obuf);
							}
							if(px){
								// if "X", display status bits
								sprintf(obuf,"stats:     s0: %04x, s3: %04x",adc_buf[0],adc_buf[j-1]);
								putsQ(obuf);
							}
							waitpio(100);
						}while(bchar != ESC);
#endif
					}
					break;

					
				case tstuart1:													// HOST MEM WR CMD
#ifdef DEBUG
					// Test Uart0:  TSTU0 ?/<string>/W to loop
					ii = 1;
					putsQ("UART0 (ACU) loop test.");
					disp_esc(pw);												// display "press esc to exit" if pw is true
					parse_ehex(args[1]);										// parse control chrs
					do{
						if(ii != 0){											// if string is ready,
					    	putsQ("Sent: ");									// display sent string..
							putsNQ(args[1]);										// ..with hex expanded
							puts0(args[1]);										// send test string to CCMD bus
							ii = 0;												// clear string ready flag
							t = args[1];										// point to start of param string
						}
//						if(gotmsgn()){
							s = gets(obuf);									// get recvd data
							*s = '\0';											// add EOS
							putsQ("Rcvd: ");									// display rcvd string
							putsNQ(obuf);										// display with hex expanded
//						}
						if(gotchr()){
							c = getchr();
							*t++ = c;											// re-fill buffer
							if((c == '\n') || (c == '\r')){
								ii = 1;											// if EOL, set string valid
								*t = '\0';										// null term
							}
						}
					}while(pw && (bchar != ESC));								// if "W" for loop, repeat until ESC
					if(pw) putsQ("");
#endif
					break;
#define	deelay	5
				case trig_la:													// LCD debug trigger
#ifdef DEBUG
					putsQ("LCD CMD line (ESC to exit)...\n");
					bchar = 0;
					l = 0x41;
					j = 0xe0;
					m = 1;
					do{
						switch(bchar){
						default:
						case 0:
//							if(bchar != ESC) bchar = 0;
							break;

						case 'R':
							reset_lcd();											// reset the LCD chipset
							wait2(deelay);
							put_spi(lcd_init_00,3);									// send captured init data
							wait2(deelay);
							put_spi(lcd_init_00b,3);
							wait2(deelay);
							l = 0x41;
							j = 0xe0;
							putsQ("Reset\n");
							if(bchar != ESC) bchar = 0;
							break;

						case '1':
							l = 0x41;
							putsQ("CS1\n");
							if(bchar != ESC) bchar = 0;
							break;

						case '2':
							l = 0x81;
							putsQ("CS2\n");
							if(bchar != ESC) bchar = 0;
							break;

						case '3':
							l = 0x81;
							putsQ("spi loop test\n");
							do{
								wait2(deelay);
								put_spi(lcd_init_00,3);								// send captured init data
								wait2(deelay);
								put_spi(lcd_init_00b,3);
								wait2(1000);
							}while(bchar != ESC);
							if(bchar != ESC) bchar = 0;
							break;

						case 'o':
							putsQ("disp on\n");
							put_spi(lcd_init_21,3);									// send captured init data
							wait2(deelay);
							put_spi(lcd_init_21b,3);
							wait2(deelay);
							if(bchar != ESC) bchar = 0;
							break;

						case 'w':
							putsQ("wr: ");
							bchar = 0;
							while((bchar != ESC) && (!bchar));						// wait for chr
							if(bchar != ESC){
								obuf[0] = bchar;
								obuf[1] = 0;
								putsQ(obuf);
								i = (asc_hex(bchar) & 0xf) | WR_DMEM;
								dbuf[0] = l+1;
								dbuf[1] = j;
								dbuf[2] = i;
								put_spi(dbuf,3);
								sprintf(obuf,"%02x\n",i & 0x0f);
								putsQ(obuf);
							}
							if(bchar != ESC) bchar = 0;
							break;

						case 'b':
							putsQ("bl: ");
							bchar = 0;
							while((bchar != ESC) && (!bchar));						// wait for chr
							if(bchar != ESC){
								obuf[0] = bchar;
								obuf[1] = 0;
								putsQ(obuf);
								i = (asc_hex(bchar) & 0xf) | WR_BMEM;
								dbuf[0] = l+1;
								dbuf[1] = j;
								dbuf[2] = i;
								put_spi(dbuf,3);
								sprintf(obuf,"%02x\n",i & 0x0f);
								putsQ(obuf);
							}
							if(bchar != ESC) bchar = 0;
							break;

						case 'p':
							putsQ("ptr: ");
							bchar = 0;
							while((bchar != ESC) && (!bchar));
							if(bchar != ESC){
								obuf[0] = bchar;
								obuf[1] = 0;
								putsQ(obuf);
								j = (asc_hex(bchar) << 4) & 0x10;
							}
							bchar = 0;
							while((bchar != ESC) && (!bchar));						// wait for chr
							if(bchar != ESC){
								obuf[0] = bchar;
								obuf[1] = 0;
								putsQ(obuf);
								j |= (asc_hex(bchar) & 0xf) | 0xe0;
								dbuf[0] = l;
								dbuf[1] = j;
								put_spi(dbuf,3);
								sprintf(obuf,"%02x\n",j & 0x1f);
								putsQ(obuf);
							}
							if(bchar != ESC) bchar = 0;
							break;

						case 'L':
							putsQ("Lamp test.\n");
							l = 0x41;
							j = 0xe0;
							for(i=0; i<0x20; i++){
								dbuf[0] = l+1;
								dbuf[1] = j++;
								dbuf[2] = 0xdf;
								put_spi(dbuf,3);
							}
							l = 0x81;
							j = 0xe0;
							for(i=0; i<0x20; i++){
								dbuf[0] = l+1;
								dbuf[1] = j++;
								dbuf[2] = 0xdf;
								put_spi(dbuf,3);
							}
							if(bchar != ESC) bchar = 0;
							break;

						case 'c':
							putsQ("clear mem.\n");
							dbuf[0] = 0x41;
							dbuf[1] = CLR_DMEM;
							put_spi(dbuf,CS_OPENCLOSE);
							dbuf[0] = 0x81;
							put_spi(dbuf,CS_OPENCLOSE);
							if(bchar != ESC) bchar = 0;
							break;

						case 'l':
							putsQ("Lamp test2.\n");
							put_spi(lcd_test_01a,1);
							put_spi(lcd_test_01,2);
							put_spi(lcd_test_01b,3);
							put_spi(lcd_test_02a,1);
							put_spi(lcd_test_02,2);
							put_spi(lcd_test_02b,3);
							if(bchar != ESC) bchar = 0;
							break;

						case 'f':
							putsQ("freq test.\n");
//							mfreq(0x045450L, 0);
							mfreq(29450L, 0);
							sfreq(1296450L, 0);
							if(bchar != ESC) bchar = 0;
							break;

						case 's':
							putsQ("msmet.\n");
							ssmet(m, 0);
							msmet(m++, 0);
							if(m > 7) m = 0;
							if(bchar != ESC) bchar = 0;
							break;
						}
					}while(bchar != ESC);
					sprintf(obuf,"Done.\n");
					putsQ(obuf);
#endif
					break;

				case dis_la:												// disarm (stop) analyzer
/*					reset_lcd();
					sprintf(obuf,"RST LCD.\n");
					putsQ(obuf);*/

					params[0] = 0;
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					dpl_cmd(obuf, &params[0], ps);
					break;

				case list_la:												// list analyzer
					sprintf(obuf,"UX present = %02x", get_present());
					putsQ(obuf);
					sscanf(args[1],"%d",&jj);								// get param
					if(jj == 0){
						GPIO_PORTC_DATA_R &= ~(MRX_N | SRX_N);
						GPIO_PORTD_DATA_R &= ~MTX_N;
					}
					if(jj == 1){
						GPIO_PORTC_DATA_R |= MRX_N;
					}
					if(jj == 2){
						GPIO_PORTC_DATA_R |= SRX_N;
					}
					if(jj == 3){
						GPIO_PORTD_DATA_R |= MTX_N;
					}
					break;

				case bttest:
					putsQ("BTtst");
/*					if(gotmsgn()){
						getss(obuf);
						putssQ("{");
						putsQ(obuf);
						putssQ("}");
					}*/
					putss(args[1]);
//					putssQ(args[1]);
//					wait(1100);
//					putss("\r");
/*					do{
						if(gotmsgn(0)){
							putsQ(get_btptr());
							clr_btptr();
							gotmsgn(1);
						}
					}while(bchar != ESC);*/
//					putss("---\r");
					break;

enums
CMD_9, CMD_10, CMD_2, CMD_23, CMD_19, CMD_8, 
ENUM_9, ENUM_10, ENUM_2, ENUM_23, ENUM_19, ENUM_8, 