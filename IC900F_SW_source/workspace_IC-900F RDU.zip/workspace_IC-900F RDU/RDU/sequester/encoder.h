/********************************************************************
 ************ COPYRIGHT (c) 2021 by ke0ff, Taylor, TX   *************
 *
 *  File name: encoder.h
 *
 *  Module:    Control, encoder header file
 *
 *  Summary:   defines and global declarations for encoder.c
 *
 *******************************************************************/

#include "typedef.h"
#include <stdint.h>

#ifndef ENCODER_H
#define ENCODER_H
#endif

////////////////////////////////////////////////////////////////////////////////////////
//#define	USE_QSPI 1																  //
////////////////////////////////////////////////////////////////////////////////////////

//-----------------------------------------------------------------------------
// Global Constants
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------

#ifndef ENCODER_C
//extern U16	var1;		// an external var
#endif

#define	ENC_UPDATE	0x80				// update flag
#define	STATE_ENCA0	0					// encoder state labels
#define	STATE_ENCA1	1
#define	STATE_ENCB0	2
#define	STATE_ENCB1	3

#define	ENC0_CHNG	1					// encoder change bit labels
#define	ENC1_CHNG	2
#define	ENC2_CHNG	4
#define	ENC3_CHNG	8

//-----------------------------------------------------------------------------
// encoder.c Fn prototypes
//-----------------------------------------------------------------------------

void set_pos0(U16 opr);
U16 get_pos0(void);
U8 get_encstat0(U8 opr);
void set_pos1(U16 opr);
U16 get_pos1(void);
U8 get_encstat1(U8 opr);
void set_pos2(U16);
U16 get_pos2(void);
U8 get_encstat2(U8 opr);
void set_pos3(U16);
U16 get_pos3(void);
U8 get_encstat3(U8 opr);
void encoder_init(void);

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------
