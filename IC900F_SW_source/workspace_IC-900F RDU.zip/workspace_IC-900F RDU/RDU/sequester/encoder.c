/********************************************************************
 ************ COPYRIGHT (c) 2021 by ke0ff, Taylor, TX   *************
 *
 *  File name: encoder.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  This file holds functions and data structures to support the Tiva
 *		QEI peripheral.
 *
 *  Project scope revision history:
 *    <VERSION 0.0>
 *    08-05-21 jmh:  Creation Date - Copied source from KPU project
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    08-05-21 jmh:  creation date
 *
 *******************************************************************/

//-----------------------------------------------------------------------------
// encoder.c
//  Interfaces QEI to main application
//
//
//  I/O Resource Map:
//      See "init.h"
//
//	SW: Basic functions:
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
// compile defines

#define ENCODER_C
#include <stdint.h>
#include "inc/tm4c123gh6pm.h"
#include <stdio.h>
#include <string.h>
#include "init.h"
#include "typedef.h"
#include "tiva_init.h"
#include "encoder.h"

//-----------------------------------------------------------------------------
// Definitions
//-----------------------------------------------------------------------------

//  see init.h for main #defines

//-----------------------------------------------------------------------------
// Local Variables
//-----------------------------------------------------------------------------

// Processor I/O assignments

U8		enc2_state;						// encoder 2 state reg
U8		enc3_state;						// encoder 3 state reg
U8		enc2_flag;						// encoder 2 update flag
U8		enc3_flag;						// encoder 3 update flag
U16		encpos2;						// encoder 2 pos
U16		encpos3;						// encoder 3 pos
U16		encreg0;						// encoder 0 reg (last sampled value..used to determine if enc has changed)
U16		encreg1;						// encoder 1 reg
U16		encreg2;						// encoder 2 reg
U16		encreg3;						// encoder 3 reg

//-----------------------------------------------------------------------------
// Local Prototypes
//-----------------------------------------------------------------------------



//-----------------------------------------------------------------------------
// get_enc_status() returns true if any encoder change
//-----------------------------------------------------------------------------
U8 get_enc_status(U8* keyh_mem){
	U8	rtn = 0;
/*
	if(chg & ENC0_CHNG){							// enc0 changes detected
		get_encstat0(CLR);							// update encoder pos.
		sprintf(buf,"e0%04X",get_pos0());			// produce msg
		putsQ(buf);									// send to UART
	}
	if(chg & ENC1_CHNG){							// enc1 changes detected
		get_encstatQ(CLR);							// update encoder pos.
		sprintf(buf,"e1%04X",get_posQ());			// produce msg
		putsQ(buf);									// send to UART
	}
	if(chg & ENC2_CHNG){							// enc2 changes detected
		get_encstat2(CLR);							// update encoder pos.
		sprintf(buf,"e2%04X",get_pos2());			// produce msg
		putsQ(buf);									// send to UART
	}
	if(chg & ENC3_CHNG){							// enc3 changes detected
		get_encstat3(CLR);							// update encoder pos.
		sprintf(buf,"e3%04X",get_pos3());			// produce msg
		putsQ(buf);									// send to UART
	}
*/
	if(get_encstat0(NOP)) rtn |= ENC0_CHNG;
	if(get_encstat1(NOP)) rtn |= ENC1_CHNG;
	if(get_encstat2(NOP)) rtn |= ENC2_CHNG;
	if(get_encstat3(NOP)) rtn |= ENC3_CHNG;
	return rtn;
}

//-----------------------------------------------------------------------------
// set_pos0
//-----------------------------------------------------------------------------
//
// sets encoder #0 position to new value.
//
void set_pos0(U16 opr){

	QEI0_POS_R = opr;
	encreg0 = opr;
	return;
}

//-----------------------------------------------------------------------------
// get_pos0
//-----------------------------------------------------------------------------
//
// returns encoder #0 reg.
//
U16 get_pos0(void){

	return QEI0_POS_R;
}

//-----------------------------------------------------------------------------
// get_encstat0
//-----------------------------------------------------------------------------
//
// returns true if encoder #0 position has changed since last time this fn was called.
//	if opr is true, update the compare reg.
//
U8 get_encstat0(U8 opr){
	U8	rtn = FALSE;
	U16	pos = QEI0_POS_R;

	if(pos != encreg0) rtn = TRUE;
	if(opr && rtn) encreg0 = pos;
	return rtn;
}

//-----------------------------------------------------------------------------
// set_pos1
//-----------------------------------------------------------------------------
//
// sets encoder #1 position to new value.
//
void set_pos1(U16 opr){

	QEI1_POS_R = opr;
	encreg1 = opr;
	return;
}

//-----------------------------------------------------------------------------
// get_pos1
//-----------------------------------------------------------------------------
//
// returns encoder #1 reg.
//
U16 get_pos1(void){

	return QEI1_POS_R;
}

//-----------------------------------------------------------------------------
// get_encstat1
//-----------------------------------------------------------------------------
//
// returns true if encoder #1 position has changed since last time this fn was called.
//	if opr is true, update the compare reg.
//
U8 get_encstat1(U8 opr){
	U8	rtn = FALSE;
	U16	pos = QEI1_POS_R;

	if(pos != encreg1) rtn = TRUE;
	if(opr && rtn) encreg1 = pos;
	return rtn;
}

//-----------------------------------------------------------------------------
// set_pos2
//-----------------------------------------------------------------------------
//
// sets encoder #2 reg.
//
void set_pos2(U16 pos){

	encpos2 = pos;
	return;
}

//-----------------------------------------------------------------------------
// get_pos2
//-----------------------------------------------------------------------------
//
// returns encoder #2 reg.
//
U16 get_pos2(void){

	return encpos2;
}

//-----------------------------------------------------------------------------
// get_encstat2
//-----------------------------------------------------------------------------
//
// returns encoder #2 status.
//
U8 get_encstat2(U8 opr){
	U8	rtn;

	NVIC_DIS0_R = NVIC_EN0_GPIOB;				// disable enc2 intrpt around these acesses
	rtn = enc2_flag;
	if(opr && rtn) enc2_flag = 0;
	NVIC_EN0_R = NVIC_EN0_GPIOB;				// re-enable
	return rtn;
}

//-----------------------------------------------------------------------------
// set_pos3
//-----------------------------------------------------------------------------
//
// sets encoder #3 reg.
//
void set_pos3(U16 pos){

	encpos3 = pos;
	return;
}

//-----------------------------------------------------------------------------
// get_pos3
//-----------------------------------------------------------------------------
//
// returns encoder #3 reg.
//
U16 get_pos3(void){

	return encpos3;
}

//-----------------------------------------------------------------------------
// get_encstat3
//-----------------------------------------------------------------------------
//
// returns encoder #3 status.
//
U8 get_encstat3(U8 opr){
	U8	rtn;

	NVIC_DIS0_R = NVIC_EN0_GPIOD;				// disable enc2 intrpt around these accesses
	rtn = enc3_flag;
	if(opr && rtn) enc3_flag = 0;
	NVIC_EN0_R = NVIC_EN0_GPIOD;				// re-enable
	return rtn;
}

//-----------------------------------------------------------------------------
// encoder_init
//-----------------------------------------------------------------------------
//
// encoder_init() initializes the GPIO quadrature encoder ISR.
//

void encoder_init(void){

	// init enc 3
	GPIO_PORTD_IM_R &= ~(DIAL_UP|DIAL_DN);					// disable interrupts
	encpos3 = 0;											// encoder pos = 0 to start
	enc3_flag = 0;											// init encoder update flag
	GPIO_PORTD_IS_R &= ~(DIAL_UP|DIAL_DN);					// edge sense
	GPIO_PORTD_IBE_R |= (DIAL_UP|DIAL_DN);					// both edges
	if(GPIO_PORTD_DATA_R & DIAL_UP){
		enc3_state = STATE_ENCA1;							// init state reg
	}else{
		enc3_state = STATE_ENCA0;							// init state reg
	}
	GPIO_PORTD_ICR_R = (DIAL_UP|DIAL_DN);					// pre-clear interrupts
	GPIO_PORTD_IM_R |= DIAL_UP;								// enable A interrupts
	NVIC_EN0_R = NVIC_EN0_GPIOD;

    return;
}

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------

